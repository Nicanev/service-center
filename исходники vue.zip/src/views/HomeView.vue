<template>
  <div>
    <HeroSection />
    <ServiceSection />
    <AboutSection />
    <ReviewsSection />
    <CompletedOrdersSection />
    <CheckListSection />
    <GiftsSection />
    <AboutUsSection />
    <LidFormSection />
    <ContactSection />
  </div>
</template>

<script setup>
import HeroSection from "@/components/HeroSection.vue";
import ServiceSection from "@/components/ServiceSection.vue";
import AboutSection from "@/components/AboutSection.vue";
import ReviewsSection from "@/components/ReviewsSection.vue";
import CompletedOrdersSection from "@/components/CompletedOrdersSection.vue";
import CheckListSection from "@/components/CheckListSection.vue";
import GiftsSection from "@/components/GiftsSection.vue";
import AboutUsSection from "@/components/AboutUsSection.vue";
import LidFormSection from "@/components/LidFormSection.vue";
import ContactSection from "@/components/ContactsSection.vue";
</script>
