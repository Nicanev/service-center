<template>
  <section class="lid">
    <div class="lid__container">
      <div class="lid__body">
        <div class="lid__text">
          <div class="lid__percent">
            50%
            <svg
              viewBox="0 0 185 213"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g filter="url(#filter0_dddddd_3_648)">
                <path
                  d="M104.089 19.028C103.723 14.2556 101.501 11.2649 99.5406 8.62578C97.7255 6.18254 96.1578 4.07266 96.1578 0.960289C96.1578 0.710289 96.0178 0.481789 95.7958 0.367226C95.5731 0.251977 95.3056 0.270852 95.1031 0.417976C92.1591 2.5246 89.7028 6.07516 88.8447 9.46291C88.249 11.8215 88.1702 14.473 88.1591 16.2242C85.4404 15.6435 84.8245 11.5767 84.818 11.5324C84.7874 11.3215 84.6585 11.1379 84.471 11.0377C84.2816 10.9387 84.0589 10.9315 83.8668 11.0266C83.7243 11.0956 80.3675 12.8012 80.1721 19.6113C80.1585 19.8378 80.1578 20.0651 80.1578 20.2923C80.1578 26.9083 85.5413 32.2915 92.1578 32.2915C92.167 32.2921 92.1767 32.2934 92.1845 32.2915C92.1871 32.2915 92.1897 32.2915 92.193 32.2915C98.7933 32.2725 104.158 26.8967 104.158 20.2923C104.158 19.9596 104.089 19.028 104.089 19.028Z"
                  fill="#FF6B00"
                />
              </g>
              <path
                d="M92.1578 30.7925C88.8492 30.7925 86.1579 27.9166 86.1579 24.3814C86.1579 24.2609 86.1569 24.1394 86.1656 23.9906C86.2057 22.4997 86.488 21.482 86.7975 20.805C87.3776 22.055 88.4147 23.204 90.0992 23.204C90.652 23.204 91.0992 22.7553 91.0992 22.2009C91.0992 20.7728 91.1286 19.1252 91.483 17.6382C91.7985 16.3197 92.5523 14.9169 93.5074 13.7925C93.9322 15.252 94.7604 16.4333 95.569 17.5863C96.7262 19.2358 97.9224 20.9412 98.1324 23.8495C98.1451 24.0219 98.1578 24.1953 98.1578 24.3814C98.1576 27.9165 95.4663 30.7925 92.1578 30.7925Z"
                fill="#FFD66B"
              />
              <defs>
                <filter
                  id="filter0_dddddd_3_648"
                  x="0.157837"
                  y="0.29248"
                  width="184"
                  height="212"
                  filterUnits="userSpaceOnUse"
                  color-interpolation-filters="sRGB"
                >
                  <feFlood flood-opacity="0" result="BackgroundImageFix" />
                  <feColorMatrix
                    in="SourceAlpha"
                    type="matrix"
                    values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha"
                  />
                  <feOffset dy="2.76726" />
                  <feGaussianBlur stdDeviation="1.1069" />
                  <feColorMatrix
                    type="matrix"
                    values="0 0 0 0 1 0 0 0 0 0.419608 0 0 0 0 0 0 0 0 0.0477948 0"
                  />
                  <feBlend
                    mode="normal"
                    in2="BackgroundImageFix"
                    result="effect1_dropShadow_3_648"
                  />
                  <feColorMatrix
                    in="SourceAlpha"
                    type="matrix"
                    values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha"
                  />
                  <feOffset dy="6.6501" />
                  <feGaussianBlur stdDeviation="2.66004" />
                  <feColorMatrix
                    type="matrix"
                    values="0 0 0 0 1 0 0 0 0 0.419608 0 0 0 0 0 0 0 0 0.0686618 0"
                  />
                  <feBlend
                    mode="normal"
                    in2="effect1_dropShadow_3_648"
                    result="effect2_dropShadow_3_648"
                  />
                  <feColorMatrix
                    in="SourceAlpha"
                    type="matrix"
                    values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha"
                  />
                  <feOffset dy="12.5216" />
                  <feGaussianBlur stdDeviation="5.00862" />
                  <feColorMatrix
                    type="matrix"
                    values="0 0 0 0 1 0 0 0 0 0.419608 0 0 0 0 0 0 0 0 0.085 0"
                  />
                  <feBlend
                    mode="normal"
                    in2="effect2_dropShadow_3_648"
                    result="effect3_dropShadow_3_648"
                  />
                  <feColorMatrix
                    in="SourceAlpha"
                    type="matrix"
                    values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha"
                  />
                  <feOffset dy="22.3363" />
                  <feGaussianBlur stdDeviation="8.93452" />
                  <feColorMatrix
                    type="matrix"
                    values="0 0 0 0 1 0 0 0 0 0.419608 0 0 0 0 0 0 0 0 0.101338 0"
                  />
                  <feBlend
                    mode="normal"
                    in2="effect3_dropShadow_3_648"
                    result="effect4_dropShadow_3_648"
                  />
                  <feColorMatrix
                    in="SourceAlpha"
                    type="matrix"
                    values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha"
                  />
                  <feOffset dy="41.7776" />
                  <feGaussianBlur stdDeviation="16.711" />
                  <feColorMatrix
                    type="matrix"
                    values="0 0 0 0 1 0 0 0 0 0.419608 0 0 0 0 0 0 0 0 0.122205 0"
                  />
                  <feBlend
                    mode="normal"
                    in2="effect4_dropShadow_3_648"
                    result="effect5_dropShadow_3_648"
                  />
                  <feColorMatrix
                    in="SourceAlpha"
                    type="matrix"
                    values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
                    result="hardAlpha"
                  />
                  <feOffset dy="100" />
                  <feGaussianBlur stdDeviation="40" />
                  <feColorMatrix
                    type="matrix"
                    values="0 0 0 0 1 0 0 0 0 0.419608 0 0 0 0 0 0 0 0 0.17 0"
                  />
                  <feBlend
                    mode="normal"
                    in2="effect5_dropShadow_3_648"
                    result="effect6_dropShadow_3_648"
                  />
                  <feBlend
                    mode="normal"
                    in="SourceGraphic"
                    in2="effect6_dropShadow_3_648"
                    result="shape"
                  />
                </filter>
              </defs>
            </svg>
          </div>
          <div class="lid__title">
            Записаться на диагностику в <span>удобное</span> вам время
          </div>
        </div>
        <form class="lid__form">
          <input type="text" placeholder="День" required />
          <input type="text" placeholder="Время" class="time" required />
          <input type="tel" placeholder="Телефон" required />
          <button>Записаться</button>
        </form>
      </div>
    </div>
  </section>
</template>

<style lang="scss">
.lid {
  margin-bottom: 11rem;
  &__body {
    @media (max-width: 48em) {
      width: 60rem;
      padding: 0 3rem;
      padding-bottom: 3rem;
    }
    width: 130rem;
    margin: 0 auto;
    border-radius: 3rem;
    border: 0.1rem solid #c7d1d7;
    display: flex;
    justify-content: space-between;
    padding: 0 11rem;
    padding-bottom: 3rem;
    @media (max-width: 48em) {
      flex-direction: column;
    }
  }
  &__title {
    margin-top: -5rem;
    font-size: 4.8rem;
    font-family: "Bebas Neue", sans-serif;
    color: #13171d;
    max-width: 37.7rem;
    span {
      color: #e2001a;
    }
  }
  &__form {
    margin-top: 4.7rem;
    display: flex;
    flex-wrap: wrap;
    gap: 2.5rem;
    width: 53rem;
    .time {
      width: 26rem;
    }
    input {
      color: #646464;
      height: 6.4rem;
      width: 24rem;
      text-indent: 2.4rem;
      font-size: 1.4rem;
      border: 0.1rem solid #dadada;
      border-radius: 1.5rem;
      background-color: transparent;
    }
    input[type="tel"] {
      width: 100%;
    }
    button {
      background: #e2001a;
      color: white;
      border-radius: 1.5rem;
      font-size: 1.6rem;
      font-weight: 600;
      border: none;
      padding: 1.8rem 7.1rem;
      cursor: pointer;
      &:hover {
        background-color: #fc142f;
        transition: 0.2s;
      }
      &:active {
        box-shadow: inset 0px 3px 0px #d10018;
      }
    }
  }
  &__percent {
    color: #ff6b00;
    position: relative;
    max-width: max-content;
    bottom: 5rem;
    font-family: "Bebas Neue", sans-serif;
    background-color: #f4f9fc;
    font-size: 11.3rem;
    text-shadow: 0px 100px 80px rgba(255, 107, 0, 0.11),
      0px 46.233px 36.9864px rgba(255, 107, 0, 0.0815843),
      0px 26.4535px 21.1628px rgba(255, 107, 0, 0.0689459),
      0px 16.0571px 12.8457px rgba(255, 107, 0, 0.0593943),
      0px 9.67509px 7.74008px rgba(255, 107, 0, 0.0506057),
      0px 5.38772px 4.31018px rgba(255, 107, 0, 0.0410541),
      0px 2.31722px 1.85378px rgba(255, 107, 0, 0.0284157);
    svg {
      position: absolute;
      width: 15rem;
      top: 5rem;
      right: -10rem;
      top: 0rem;
    }
  }
}
</style>
