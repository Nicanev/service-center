<template>
  <section class="about-us">
    <div class="about-us__container">
      <svg
        class="wave"
        viewBox="0 0 99 63"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M98.7959 61.4091C98.7235 60.917 98.311 60.5406 97.8115 60.5334C96.0163 60.5045 91.6513 59.9255 87.2502 55.5251C81.0249 49.3009 78.0932 48.208 74.2422 48.208C70.0076 48.208 65.3892 50.495 61.2342 54.6493C57.0285 58.8543 53.7856 60.49 49.6667 60.49C45.4538 60.49 41.1612 56.8278 38.9751 54.6493C36.7456 52.4202 31.1573 48.208 25.9672 48.208C21.4936 48.208 17.1649 51.4721 13.683 54.0921L13.0678 54.5553C12.4018 55.0546 11.7648 55.583 11.1495 56.0968C8.60868 58.2174 6.19095 60.2294 1.47131 60.4683C0.935642 60.4972 0.508545 60.9459 0.508545 61.4815C0.508545 62.0677 1.00082 62.5309 1.58715 62.502C6.98724 62.2197 9.88269 59.8024 12.4524 57.6601C13.075 57.139 13.6613 56.6469 14.2839 56.1837L14.9064 55.7133C18.1421 53.2742 22.1668 50.2417 25.9599 50.2417C29.6734 50.2417 34.6898 53.2525 37.5274 56.0824C39.9306 58.4852 44.7082 62.5237 49.6595 62.5237C54.3212 62.5237 58.0926 60.6564 62.6674 56.0824C66.4388 52.3116 70.5432 50.2417 74.235 50.2417C77.1594 50.2417 79.5482 50.7122 85.8024 56.9653C90.6886 61.8579 95.5964 62.5454 97.7825 62.5744C98.405 62.5888 98.89 62.0316 98.7959 61.4091Z"
          fill="#FFD66B"
        />
        <path
          d="M98.7959 37.583C98.7235 37.0908 98.311 36.7145 97.8115 36.7072C96.0163 36.6783 91.6513 36.0993 87.2502 31.6989C81.0249 25.4747 78.0932 24.3818 74.2422 24.3818C70.0076 24.3818 65.3892 26.6689 61.2342 30.8232C57.0285 35.0281 53.7856 36.6638 49.6667 36.6638C45.4538 36.6638 41.1612 33.0017 38.9751 30.8232C36.7456 28.594 31.1573 24.3818 25.9672 24.3818C21.4936 24.3818 17.1649 27.6459 13.683 30.2659L13.0678 30.7291C12.4018 31.2285 11.7648 31.7568 11.1495 32.2707C8.60868 34.3912 6.19095 36.4033 1.47131 36.6421C0.935642 36.671 0.508545 37.1198 0.508545 37.6553C0.508545 38.2416 1.00082 38.7048 1.58715 38.6758C6.98724 38.3936 9.88269 35.9763 12.4524 33.834C13.075 33.3129 13.6613 32.8207 14.2839 32.3575L14.9064 31.8871C18.1421 29.4481 22.1668 26.4156 25.9599 26.4156C29.6734 26.4156 34.6898 29.4263 37.5274 32.2562C39.9306 34.659 44.7082 38.6975 49.6595 38.6975C54.3212 38.6975 58.0926 36.8303 62.6674 32.2562C66.4388 28.4855 70.5432 26.4156 74.235 26.4156C77.1594 26.4156 79.5482 26.886 85.8024 33.1392C90.6886 38.0244 95.5964 38.712 97.7825 38.7482C98.405 38.7627 98.89 38.2054 98.7959 37.583Z"
          fill="#FFD66B"
        />
        <path
          d="M1.58654 14.8575C6.98663 14.5752 9.88208 12.1579 12.4518 10.0156C13.0744 9.4945 13.6607 9.00236 14.2832 8.53916L14.9058 8.06872C18.1415 5.6297 22.1662 2.5972 25.9593 2.5972C29.6728 2.5972 34.6892 5.60799 37.5268 8.43783C39.93 10.8407 44.7076 14.8792 49.6589 14.8792C54.3206 14.8792 58.092 13.0119 62.6668 8.43783C66.4382 4.66712 70.5426 2.5972 74.2344 2.5972C77.1588 2.5972 79.5476 3.06764 85.8018 9.3208C90.688 14.2061 95.5958 14.8936 97.7819 14.9298C98.4044 14.9371 98.8894 14.3798 98.7953 13.7646C98.7229 13.2725 98.3103 12.8961 97.8109 12.8889C96.0157 12.8599 91.6507 12.2809 87.2496 7.88055C81.0243 1.65633 78.0926 0.563477 74.2416 0.563477C70.0069 0.563477 65.3886 2.85051 61.2336 7.00481C57.0279 11.2098 53.785 12.8454 49.6661 12.8454C45.4532 12.8454 41.1606 9.18329 38.9745 7.00481C36.745 4.77568 31.1567 0.563477 25.9666 0.563477C21.493 0.563477 17.1642 3.82757 13.6824 6.44753L13.0671 6.91073C12.4012 7.41011 11.7642 7.93845 11.1489 8.45231C8.60807 10.5729 6.19034 12.5849 1.4707 12.8237C0.935032 12.8527 0.507935 13.3014 0.507935 13.837C0.507935 14.4232 1.00744 14.8864 1.58654 14.8575Z"
          fill="#FFD66B"
        />
      </svg>
      <svg
        class="elipse"
        viewBox="0 0 50 50"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M40 0.29248C45.5229 0.29248 50.1005 4.81325 49.0033 10.226C48.3663 13.3685 47.4269 16.45 46.194 19.4267C43.6812 25.4929 39.9983 31.0049 35.3553 35.6478C30.7124 40.2907 25.2005 43.9737 19.1342 46.4865C16.1575 47.7194 13.076 48.6588 9.93353 49.2958C4.52077 50.393 1.95703e-07 45.8153 4.37114e-07 40.2925L1.74846e-06 10.2925C1.98987e-06 4.76963 4.47715 0.29248 10 0.29248H40Z"
          fill="#FFD66B"
        />
      </svg>

      <div class="about-us__title">
        В нашей компании работают лучшие специалисты, которые прекрасно
        разбираются в современных технологиях и имеют более 3-х лет опыта
        работы.
      </div>
      <div class="about-us__main">
        <div class="about-us__text">
          <p>
            За счет этого мы гарантируем устранение любых неполадок и
            предоставляем гарантию на все выполненные работы.
          </p>
          <p>
            Мы поможем не только восстановить работоспособность техники, но и
            подскажем, как избежать возникновения подобных поломок в будущем.
          </p>
          <p>
            Квалифицированная консультация специалиста поможет безопасно
            пользоваться компьютером. В нашем штате работают опытные
            специалисты.
          </p>
        </div>
        <div class="about-us__swiper">
          <button ref="prev" class="about-us__prev"></button>
          <Swiper
            :navigation="{
              prevEl: prev,
              nextEl: next,
            }"
            :pagination="{ clickable: true, el: '.about-us__pagination' }"
            :slides-per-view="1"
            :loop="true"
            :modules="modules"
          >
            <swiper-slide
              ><img src="@/assets/img/about-us/1.png" />
            </swiper-slide>
            <swiper-slide
              ><img src="@/assets/img/about-us/1.png"
            /></swiper-slide>

            <swiper-slide
              ><img src="@/assets/img/about-us/1.png"
            /></swiper-slide>
          </Swiper>
          <button ref="next" class="about-us__next"></button>
          <div class="about-us__pagination"></div>
        </div>
      </div>
    </div>
  </section>
</template>

<style lang="scss">
.about-us {
  margin-bottom: 20rem;
  &__container {
    .wave {
      @media (max-width: 48em) {
        display: none;
      }
      position: absolute;
      top: 20rem;
      width: 9.8rem;
      height: 6.2rem;
      path {
        fill: #005aaa;
      }
    }
    .elipse {
      @media (max-width: 48em) {
        display: none;
      }
      position: absolute;
      width: 5.6rem;
      height: 5.6rem;
      right: 0;
      bottom: -5rem;
    }
  }
  &__prev {
    @media (max-width: 48em) {
      display: none;
    }
    position: absolute;
    top: 25rem;
    z-index: 10;
    left: -3rem;
    height: 4.8rem;
    width: 4.8rem;
    background-image: url("../assets/img/icons/Arrow.svg");
    background-repeat: no-repeat;
    background-size: 2.4rem 2.4rem;
    padding: 1rem 2rem;
    border-radius: 50%;
    border: none;
    background-color: white;
    background-position: center;
    transform: rotate(180deg);
    cursor: pointer;
  }
  &__next {
    @media (max-width: 48em) {
      display: none;
    }
    position: absolute;
    top: 25rem;
    z-index: 10;
    right: -3rem;
    height: 4.8rem;
    width: 4.8rem;
    background-image: url("../assets/img/icons/Arrow.svg");
    background-repeat: no-repeat;
    background-size: 2.4rem 2.4rem;
    padding: 1rem 2rem;
    border-radius: 50%;
    border: none;
    background-color: white;
    background-position: center;
    cursor: pointer;
  }
  &__pagination {
    margin-top: 2rem;
    text-align: center;
  }
  &__main {
    @media (max-width: 48em) {
      align-items: center;
    }
    @media (max-width: 20em) {
      flex-direction: column-reverse;
      justify-content: center;
      align-items: center;
    }
    display: flex;
    justify-content: space-between;
  }
  &__text {
    @media (max-width: 48em) {
      margin-left: 0;
      margin-top: 0;
    }
    display: flex;
    flex-direction: column;
    margin-left: 27rem;
    margin-top: 10rem;
    gap: 2.4rem;
    max-width: 47rem;
    color: #646464;
    font-size: 1.8rem;
  }
  &__title {
    @media (max-width: 48em) {
      font-size: 1.8rem;
      margin-bottom: 5rem;
    }
    position: relative;
    margin: 0 auto;
    color: #13171d;
    font-size: 2.4rem;
    max-width: 70rem;
    font-weight: 500;
    text-align: center;
    margin-bottom: 10rem;
    &::before {
      @media (max-width: 48em) {
        left: -2rem;
      }
      content: "";
      position: absolute;
      background-image: url("../assets/img/icons/quotes.svg");
      background-position: center;
      background-size: 2.9rem 2rem;
      background-repeat: no-repeat;
      top: -2rem;
      left: -4rem;
      width: 2.9rem;
      height: 2rem;
    }
    &::after {
      @media (max-width: 48em) {
        right: -2rem;
      }
      content: "";
      position: absolute;
      background-image: url("../assets/img/icons/quotes.svg");
      background-position: center;
      background-repeat: no-repeat;
      background-size: 2.9rem 2rem;
      bottom: -2rem;
      right: -4rem;
      width: 2.9rem;
      height: 2rem;
      transform: rotate(180deg);
    }
  }
  &__swiper {
    @media (max-width: 48em) {
      max-width: 35rem;
    }
    max-width: 63.5rem;
    position: relative;
  }
}
</style>
<script>
import { ref } from "vue";
import { Swiper, SwiperSlide } from "swiper/vue";
import "swiper/css";
import { Navigation, Pagination } from "swiper";
import "swiper/css/pagination";
export default {
  components: {
    Swiper,
    SwiperSlide,
  },
  setup() {
    const prev = ref(null);
    const next = ref(null);
    return {
      modules: [Navigation, Pagination],
      prev,
      next,
    };
  },
};
</script>
