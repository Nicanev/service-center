<template>
  <section class="about" id="about">
    <div class="about__container">
      <svg
        class="wave"
        width="99"
        height="63"
        viewBox="0 0 99 63"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M98.7959 61.4091C98.7235 60.917 98.311 60.5406 97.8115 60.5334C96.0163 60.5045 91.6513 59.9255 87.2502 55.5251C81.0249 49.3009 78.0932 48.208 74.2422 48.208C70.0076 48.208 65.3892 50.495 61.2342 54.6493C57.0285 58.8543 53.7856 60.49 49.6667 60.49C45.4538 60.49 41.1612 56.8278 38.9751 54.6493C36.7456 52.4202 31.1573 48.208 25.9672 48.208C21.4936 48.208 17.1649 51.4721 13.683 54.0921L13.0678 54.5553C12.4018 55.0546 11.7648 55.583 11.1495 56.0968C8.60868 58.2174 6.19095 60.2294 1.47131 60.4683C0.935642 60.4972 0.508545 60.9459 0.508545 61.4815C0.508545 62.0677 1.00082 62.5309 1.58715 62.502C6.98724 62.2197 9.88269 59.8024 12.4524 57.6601C13.075 57.139 13.6613 56.6469 14.2839 56.1837L14.9064 55.7133C18.1421 53.2742 22.1668 50.2417 25.9599 50.2417C29.6734 50.2417 34.6898 53.2525 37.5274 56.0824C39.9306 58.4852 44.7082 62.5237 49.6595 62.5237C54.3212 62.5237 58.0926 60.6564 62.6674 56.0824C66.4388 52.3116 70.5432 50.2417 74.235 50.2417C77.1594 50.2417 79.5482 50.7122 85.8024 56.9653C90.6886 61.8579 95.5964 62.5454 97.7825 62.5744C98.405 62.5888 98.89 62.0316 98.7959 61.4091Z"
          fill="#FFD66B"
        />
        <path
          d="M98.7959 37.583C98.7235 37.0908 98.311 36.7145 97.8115 36.7072C96.0163 36.6783 91.6513 36.0993 87.2502 31.6989C81.0249 25.4747 78.0932 24.3818 74.2422 24.3818C70.0076 24.3818 65.3892 26.6689 61.2342 30.8232C57.0285 35.0281 53.7856 36.6638 49.6667 36.6638C45.4538 36.6638 41.1612 33.0017 38.9751 30.8232C36.7456 28.594 31.1573 24.3818 25.9672 24.3818C21.4936 24.3818 17.1649 27.6459 13.683 30.2659L13.0678 30.7291C12.4018 31.2285 11.7648 31.7568 11.1495 32.2707C8.60868 34.3912 6.19095 36.4033 1.47131 36.6421C0.935642 36.671 0.508545 37.1198 0.508545 37.6553C0.508545 38.2416 1.00082 38.7048 1.58715 38.6758C6.98724 38.3936 9.88269 35.9763 12.4524 33.834C13.075 33.3129 13.6613 32.8207 14.2839 32.3575L14.9064 31.8871C18.1421 29.4481 22.1668 26.4156 25.9599 26.4156C29.6734 26.4156 34.6898 29.4263 37.5274 32.2562C39.9306 34.659 44.7082 38.6975 49.6595 38.6975C54.3212 38.6975 58.0926 36.8303 62.6674 32.2562C66.4388 28.4855 70.5432 26.4156 74.235 26.4156C77.1594 26.4156 79.5482 26.886 85.8024 33.1392C90.6886 38.0244 95.5964 38.712 97.7825 38.7482C98.405 38.7627 98.89 38.2054 98.7959 37.583Z"
          fill="#FFD66B"
        />
        <path
          d="M1.58654 14.8575C6.98663 14.5752 9.88208 12.1579 12.4518 10.0156C13.0744 9.4945 13.6607 9.00236 14.2832 8.53916L14.9058 8.06872C18.1415 5.6297 22.1662 2.5972 25.9593 2.5972C29.6728 2.5972 34.6892 5.60799 37.5268 8.43783C39.93 10.8407 44.7076 14.8792 49.6589 14.8792C54.3206 14.8792 58.092 13.0119 62.6668 8.43783C66.4382 4.66712 70.5426 2.5972 74.2344 2.5972C77.1588 2.5972 79.5476 3.06764 85.8018 9.3208C90.688 14.2061 95.5958 14.8936 97.7819 14.9298C98.4044 14.9371 98.8894 14.3798 98.7953 13.7646C98.7229 13.2725 98.3103 12.8961 97.8109 12.8889C96.0157 12.8599 91.6507 12.2809 87.2496 7.88055C81.0243 1.65633 78.0926 0.563477 74.2416 0.563477C70.0069 0.563477 65.3886 2.85051 61.2336 7.00481C57.0279 11.2098 53.785 12.8454 49.6661 12.8454C45.4532 12.8454 41.1606 9.18329 38.9745 7.00481C36.745 4.77568 31.1567 0.563477 25.9666 0.563477C21.493 0.563477 17.1642 3.82757 13.6824 6.44753L13.0671 6.91073C12.4012 7.41011 11.7642 7.93845 11.1489 8.45231C8.60807 10.5729 6.19034 12.5849 1.4707 12.8237C0.935032 12.8527 0.507935 13.3014 0.507935 13.837C0.507935 14.4232 1.00744 14.8864 1.58654 14.8575Z"
          fill="#FFD66B"
        />
      </svg>
      <div class="about__des">
        <div class="about__text">
          <div class="about__title">О компании Arron</div>
          <div class="about__subtitle">
            Узнайте о нашей компании больше из видео за 1 минуту.
          </div>
        </div>
        <button class="about__btn">
          Смотреть
          <img src="@/assets/img/about/Arrow.svg" />
        </button>
      </div>
      <div class="about__cards">
        <div class="about__card">
          <img src="@/assets/img/hero/adv1.svg" />
          <h1>Выезжаем в любую точку Кишинева</h1>
          <p></p>
        </div>
        <div class="about__card">
          <img src="@/assets/img/icons/trusted.svg" />
          <h1>Работы от 30 минут</h1>
          <p>
            Время работы или настройки занимает от 30 минут до несколько часов.
          </p>
        </div>
        <div class="about__card">
          <img src="@/assets/img/icons/payment.svg" />
          <h1>Удобный способ оплаты</h1>
          <p>Оплата наличными или по перечеслению компаниям.</p>
        </div>
        <div class="about__card">
          <img src="@/assets/img/icons/secure.svg" />
          <h1>Гарантия на все выполненые услуги</h1>
          <p>
            Запчасти, фотографии и сообщения под Вашим контролем. После работ
            инженер отдаст Вам старые запчасти.
          </p>
        </div>
      </div>
    </div>
  </section>
</template>

<style lang="scss">
.about {
  margin-bottom: 12rem;
  padding: 8rem 7rem;
  background: linear-gradient(180deg, #ebf3f8 0%, rgba(235, 243, 248, 0) 100%);
  &__container {
    position: relative;
    @media (max-width: 48em) {
      flex-direction: column;
      padding: 0 0;
      width: 100%;
    }
    display: flex;
    gap: 10rem;
    .wave {
      @media (max-width: 48em) {
        display: none;
      }
      position: absolute;
      top: 20rem;
      right: 7rem;
      width: 9.8rem;
      height: 6.2rem;
    }
  }
  &__des {
    @media (max-width: 48em) {
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
    }
    display: flex;
    flex-direction: column;
  }
  &__title {
    @media (max-width: 48em) {
      font-size: 4rem;
    }
    color: #13171d;
    font-size: 8rem;
    max-width: 54.2rem;
    font-family: "Bebas Neue", sans-serif;
  }
  &__subtitle {
    @media (max-width: 48em) {
      font-size: 1.8rem;
    }
    color: #444444;
    font-size: 2.4rem;
    max-width: 52.7rem;
  }
  &__cards {
    @media (max-width: 48em) {
      justify-content: start;
      gap: 1rem;
    }
    @media (max-width: 20em) {
      flex-direction: column;
      width: 45rem;
      justify-content: center;
      align-items: center;
    }
    display: flex;
    width: 75rem;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  &__card {
    img {
      width: 8rem;
      height: 8rem;
    }
    h1 {
      @media (max-width: 48em) {
        max-width: 23rem;
      }
      color: #13171d;
      font-size: 2rem;
      font-weight: 600;
      margin-bottom: 1.6rem;
    }
    p {
      @media (max-width: 48em) {
        width: 30rem;
      }
      color: #444444;
      font-size: 1.8rem;
      width: 33.6rem;
    }
  }
  &__btn {
    @media (max-width: 48em) {
      flex-direction: row;
      padding: 1.8rem 3rem;
      width: 18rem;
      margin-top: 0;
    }
    display: flex;
    align-items: center;
    gap: 1.6rem;
    background-color: #e2001a;
    border-radius: 1.5rem;
    border: none;
    width: 25rem;
    padding: 1.8rem 8rem;
    color: white;
    font-size: 1.6rem;
    font-weight: 600;
    height: 6.4rem;
    margin-top: 9rem;
    cursor: pointer;
    &:hover {
      background-color: #fc142f;
      transition: 0.2s;
    }
    &:active {
      box-shadow: inset 0px 3px 0px #d10018;
    }
    img {
      width: 2.4rem;
      height: 2.4rem;
    }
  }
}
</style>
